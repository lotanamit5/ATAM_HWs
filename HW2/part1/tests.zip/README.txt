just run chmod +x * in terminal
then run ./run_all.sh