#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void get_path(char* _path) {
	strcpy(_path, "./test2");
}

long atam_atol(char* num) {
	return atol(num);
}